#!/bin/sh
# iniciar.sh — ponto de entrada único de um agente. Zero contexto prévio.
#
#   sh iniciar.sh R=https://github.com/<dono>/aaaa.git A=<nome> S=<passphrase> P=wwii
#
# R é opcional (já aponta para este repo). Faz em sequência, parando na 1ª falha:
#   1 h.sh          credencial + branch do projeto + hooks + identidade
#   2 setup.sh      dependências, bate-ponto, diagnóstico T0..T4
#   3 etapa.sh      reclama a primeira etapa livre (ou retoma a que já é sua)
#   4 relatorio.sh  publica a linha que o lead lê
#
# Variáveis:
#   A  obrigatória — nome do agente (bate-ponto, git, evidência)
#   S  passphrase de t.gpg; ou S_ARQ=<arquivo>. Nunca passe S em argv num pipe.
#   M  modelo exato (ex.: claude-sonnet-5-5); entra em commits, mural e ambientes/<A>.md
#   P  projeto por nome (wwii, iaag); padrão: wwii
#   D 1 = dry-run: mostra o plano e não executa nada
#   E forçar uma etapa específica (padrão: primeira livre)
set -eu

# aceita A=<nome> P=<projeto> tanto como ambiente quanto como argumento posicional
# (com `curl ... | sh -s -- A=n P=p` o stdin ja esta tomado pelo proprio script)
for kv in "$@"; do
  case "$kv" in
    *=*) export "$kv" ;;
    *) echo "iniciar.sh: argumento nao-reconhecido: $kv"; exit 2 ;;
  esac
done

AQUI=$(cd "$(dirname "$0")" && pwd)
R=${R:-https://github.com/kkkkiiiioooo/aaaa.git}
P=${P:-wwii}
D=${D:-0}

[ -n "${A:-}" ] || { echo "iniciar.sh: falta A=<nome do agente>"; exit 2; }
if [ -z "${S:-}" ] && [ -n "${S_ARQ:-}" ] && [ -r "$S_ARQ" ]; then S=$(head -1 "$S_ARQ"); fi
if [ -z "${S:-}" ] && [ ! -t 0 ]; then S=$(head -1); fi
if [ -z "${S:-}" ]; then printf 'Passphrase de t.gpg: '; S=$(head -1); fi
[ -n "$S" ] || { echo "iniciar.sh: sem passphrase"; exit 2; }

passo() { printf '\n===== %s =====\n' "$1"; }
falha() { printf '\nPARADO em %s: %s\n' "$1" "${2:-}"; exit 1; }

if [ "$D" = 1 ]; then
  printf 'dry-run — faria:\n'
  printf '  1 git clone %s -> %s/aaaa ; sh h.sh (A=%s P=%s)\n' "$R" "$AQUI" "$A" "$P"
  printf '  2 sh setup.sh   (dependências + bate-ponto + doctor)\n'
  printf '  3 sh scripts/etapa.sh pegar ${E:-primeira livre}\n'
  printf '  4 sh scripts/relatorio.sh "<linha>"\n'
  exit 0
fi

# ---------------------------------------------------------------- 1 bootstrap
REPO="$AQUI/aaaa"
if [ ! -d "$REPO/.git" ]; then
  passo "1/4 clone"
  # blob:none = traz commits e arvores, nao o conteudo. Sem isso, a branch `imagem`
  # (317 MB de pacote offline) seria baixada por TODO agente, inclusive quem nao usa.
  git clone --filter=blob:none "$R" "$REPO" >/dev/null 2>&1 \
    || git clone "$R" "$REPO" >/dev/null 2>&1 \
    || falha "clone" "nem clone parcial nem completo funcionaram — veja a mensagem acima"
fi
cd "$REPO"
git -C "$REPO" fsck --no-dangling 2>&1 | grep -q "^error:" && falha "clone" "clone corrompido — delete $REPO e repita"

passo "1/4 credencial + branch"
# h.sh e executado a partir do PAI do clone: ele deriva o destino de onde esta,
# e executado de dentro de aaaa/ criaria aaaa/aaaa/.
git -C "$REPO" fetch origin 0 >/dev/null 2>&1 || true
git -C "$REPO" show origin/0:h.sh > "$AQUI/.h.tmp" 2>/dev/null \
  || git -C "$REPO" show origin/main:h.sh > "$AQUI/.h.tmp" 2>/dev/null \
  || falha "h.sh" "nao consegui extrair h.sh da branch 0"
( cd "$AQUI" && S="$S" A="$A" P="$P" sh .h.tmp ) || { rm -f "$AQUI/.h.tmp"; falha "h.sh"; }
rm -f "$AQUI/.h.tmp"
mkdir -p .work; echo "$A" > .work/agente; [ -n "${M:-}" ] && echo "$M" > .work/modelo || echo "AVISO: sem M=<modelo>; o dono nao saberá qual modelo é você"
echo "branch: $(git rev-parse --abbrev-ref HEAD)  como: $(git config user.name || echo "?")"

# ------------------------------------------------------------------- 2 setup
passo "2/4 ambiente"
sh setup.sh || falha "setup.sh" "ambiente incompleto — leia o diagnóstico acima antes de escrever código"

# ------------------------------------------------------------ 3 reclamar etapa
passo "3/4 etapa"
sh scripts/etapa.sh status
# autoridade de estado e o etapa.sh; aqui so lemos a saida dele
ST=$(sh scripts/etapa.sh status)
MINHA=${E:-}
if [ -z "$MINHA" ]; then
  MINHA=$(printf '%s\n' "$ST" | sed -n "s/^MINHA ETAPA: \(E[0-9]*\).*/\1/p" | head -1)
  [ -n "$MINHA" ] || MINHA=$(printf '%s\n' "$ST" | sed -n "s/^LIVRES para reclamacao: //p" | head -1 | awk '{print $1}')
fi
[ -n "$MINHA" ] || falha "etapa" "nenhuma etapa livre — pergunte ao lead"
sh scripts/etapa.sh pegar "$MINHA" || falha "etapa $MINHA"

# ----------------------------------------------------------------- 4 relatório
passo "4/4 relatório do lead"
N=$(sh scripts/doctor.sh 2>/dev/null | sed -n "s/^EXECUTAVEL AGORA: //p" | head -1); [ -n "$N" ] || N="ver doctor.sh"
sh scripts/relatorio.sh "$A | $MINHA | rodando | ambiente: $N | proximo: ver ETAPAS.md" || true

# quem ainda esta na E1 nao precisa esperar ter a imagem para comecar a pensar
if [ -f docs/imagem/DOSSIE.md ]; then
  printf '\nDOSSIER da imagem ja publicado (leia antes de codar):\n'
  sed -n '1,40p' docs/imagem/DOSSIE.md
fi

sh scripts/sync.sh || true

cat <<EOF

PRONTO. Você está em $REPO, branch $(git rev-parse --abbrev-ref HEAD), etapa $MINHA.
  leia   : AGENTS.md -> sh scripts/plano.sh -> ETAPAS.md
  trabalho: scripts/etapa.sh fechar $MINHA "<evidencia: caminho + saida>"
  status : sh scripts/etapa.sh status
EOF
